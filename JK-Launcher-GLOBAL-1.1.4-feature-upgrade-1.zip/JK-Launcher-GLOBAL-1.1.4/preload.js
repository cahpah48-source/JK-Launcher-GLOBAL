'use strict';
const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('jk', {
  getState: () => ipcRenderer.invoke('jk:state'),
  saveSettings: data => ipcRenderer.invoke('jk:save-settings', data),
  login: () => ipcRenderer.invoke('jk:login'),
  logout: () => ipcRenderer.invoke('jk:logout'),
  createProfile: data => ipcRenderer.invoke('jk:create-profile', data),
  selectProfile: id => ipcRenderer.invoke('jk:select-profile', id),
  removeProfile: id => ipcRenderer.invoke('jk:remove-profile', id),
  launch: id => ipcRenderer.invoke('jk:launch', id),
  importMrpack: () => ipcRenderer.invoke('jk:import-mrpack'),
  importMods: id => ipcRenderer.invoke('jk:import-mods', id),
  uploadSkin: () => ipcRenderer.invoke('jk:upload-skin'),
  openGameFolder: id => ipcRenderer.invoke('jk:open-game-folder', id),
  openFolder: () => ipcRenderer.invoke('jk:open-folder'),
  refreshVersions: () => ipcRenderer.invoke('jk:refresh-versions'),
  onLog: fn => ipcRenderer.on('jk:log', (_event, payload) => fn(payload)),
  onStatus: fn => ipcRenderer.on('jk:status', (_event, payload) => fn(payload)),
  onProgress: fn => ipcRenderer.on('jk:progress', (_event, payload) => fn(payload)),
  onAccount: fn => ipcRenderer.on('jk:account', (_event, payload) => fn(payload))
});
