'use strict';

const $ = id => document.getElementById(id);
let state = null;
let currentProfileId = '';
const logBuffer = [];
const views = ['play', 'instances', 'mods', 'skin', 'settings'];

function toast(message, type = '') {
  const el = document.createElement('div');
  el.className = `toast ${type}`;
  el.textContent = message;
  $('toastContainer').appendChild(el);
  setTimeout(() => el.remove(), 5200);
}
function friendlyError(error) {
  return (error && error.message) ? error.message : String(error || 'Неизвестная ошибка');
}
async function runAction(button, work, successMessage) {
  if (button) button.disabled = true;
  try {
    const result = await work();
    if (successMessage && result?.canceled !== true) toast(successMessage, 'success');
    return result;
  } catch (error) {
    toast(friendlyError(error), 'error');
    return null;
  } finally {
    if (button) button.disabled = false;
    await refreshState(false).catch(() => {});
  }
}
function appendLog(item) {
  logBuffer.push(item);
  if (logBuffer.length > 180) logBuffer.splice(0, logBuffer.length - 180);
  const list = $('logList');
  list.replaceChildren();
  for (const entry of logBuffer.slice(-50)) {
    const line = document.createElement('div');
    line.className = `log-entry ${entry.level || ''}`;
    const time = document.createElement('span');
    time.className = 'time';
    time.textContent = entry.time || '';
    line.append(time, document.createTextNode(entry.message || ''));
    list.appendChild(line);
  }
  list.scrollTop = list.scrollHeight;
}
function setStatus(payload) {
  $('statusText').textContent = payload.message || 'Готово';
  $('statusIndicator').className = `status-indicator ${payload.state || ''}`;
  $('systemText').textContent = payload.state === 'error' ? 'Требуется внимание' : payload.state === 'busy' ? 'Выполняется операция' : 'Лаунчер активен';
}
function setProgress(payload) {
  $('progressBar').style.width = `${Math.max(0, Math.min(100, payload.percent || 0))}%`;
  $('progressPercent').textContent = `${Math.round(payload.percent || 0)}%`;
  $('progressText').textContent = payload.message || 'Ожидание действия';
}
function currentProfile() {
  return state?.profiles?.find(p => p.id === currentProfileId) || state?.profiles?.[0] || null;
}
function switchView(name) {
  if (!views.includes(name)) return;
  for (const v of views) {
    $(`view-${v}`).classList.toggle('active-view', v === name);
    document.querySelector(`.nav-item[data-view="${v}"]`).classList.toggle('active', v === name);
  }
  const labels = { play: 'Главная', instances: 'Установки', mods: 'Моды и сборки', skin: 'Скин', settings: 'Настройки' };
  $('pageCrumb').textContent = labels[name];
  if (name === 'mods') renderActiveModProfile();
  if (name === 'instances') renderInstances();
  if (name === 'skin') renderSkin(state?.account);
}
function addOption(select, value, label) {
  const option = document.createElement('option');
  option.value = value;
  option.textContent = label;
  select.appendChild(option);
}
function renderVersions() {
  const select = $('mcVersionSelect');
  const previous = select.value;
  select.replaceChildren();
  if (!state?.versions?.length) {
    addOption(select, '', state?.versionsError || 'Релизы недоступны — проверьте интернет');
    return;
  }
  for (const v of state.versions) addOption(select, v.id, `${v.id}  ·  release`);
  if (state.versions.some(v => v.id === previous)) select.value = previous;
  else select.value = state.versions[0].id;
  $('visualVersion').textContent = `JAVA ${select.value || 'EDITION'}`;
}
function renderProfiles() {
  const select = $('selectedProfile');
  select.replaceChildren();
  if (!state?.profiles?.length) addOption(select, '', 'Сначала создай установку');
  else {
    state.profiles.forEach(profile => addOption(select, profile.id, `${profile.name}  ·  ${profile.mcVersion}`));
    if (state.profiles.some(p => p.id === currentProfileId)) select.value = currentProfileId;
    else { currentProfileId = state.profiles[0].id; select.value = currentProfileId; }
  }
  renderActiveProfile();
}
function renderActiveProfile() {
  const profile = currentProfile();
  $('activeVersion').textContent = profile?.mcVersion || '—';
  $('activeLoader').textContent = !profile ? '—' : ({ vanilla: 'Vanilla', fabric: 'Fabric', forge: 'Forge', neoforge: 'NeoForge' }[profile.loader] || profile.loader);
  $('activeCreated').textContent = profile?.createdAt ? new Date(profile.createdAt).toLocaleDateString('ru-RU') : '—';
  $('openInstanceFolder').disabled = !profile;
  $('playButton').disabled = !profile;
  $('playButtonText').textContent = profile ? 'ЗАПУСТИТЬ ИГРУ' : 'СОЗДАТЬ УСТАНОВКУ';
  renderActiveModProfile();
}
function renderInstances() {
  const root = $('instanceList');
  root.replaceChildren();
  const profiles = state?.profiles || [];
  if (!profiles.length) {
    const empty = document.createElement('div'); empty.className = 'empty-state';
    empty.textContent = 'Пока нет установок. Перейдите на главную и создайте профиль Minecraft или импортируйте .mrpack.';
    root.appendChild(empty); return;
  }
  for (const p of profiles) {
    const row = document.createElement('div'); row.className = 'instance-row';
    const icon = document.createElement('div'); icon.className = 'instance-row-icon'; icon.textContent = p.loader === 'vanilla' ? '▤' : '▦';
    const main = document.createElement('div'); main.className = 'instance-row-main';
    const name = document.createElement('strong'); name.textContent = p.name;
    const loaderName = ({ vanilla: 'Vanilla', fabric: 'Fabric', forge: 'Forge', neoforge: 'NeoForge' }[p.loader] || p.loader); const meta = document.createElement('span'); meta.textContent = `Minecraft ${p.mcVersion} · ${loaderName}${p.loaderVersion ? ` ${p.loaderVersion}` : ''} · ${p.source || 'Локальный профиль'}`;
    main.append(name, meta);
    const actions = document.createElement('div'); actions.className = 'instance-row-actions';
    const selectBtn = document.createElement('button'); selectBtn.className = 'button button-outline'; selectBtn.textContent = p.id === currentProfileId ? 'Активный' : 'Выбрать';
    selectBtn.addEventListener('click', () => runAction(selectBtn, async () => { await window.jk.selectProfile(p.id); currentProfileId = p.id; await refreshState(false); return true; }, 'Профиль выбран'));
    const folderBtn = document.createElement('button'); folderBtn.className = 'button button-outline'; folderBtn.textContent = 'Папка ↗';
    folderBtn.addEventListener('click', () => runAction(folderBtn, () => window.jk.openGameFolder(p.id)));
    const removeBtn = document.createElement('button'); removeBtn.className = 'button button-quiet'; removeBtn.textContent = 'Убрать';
    removeBtn.addEventListener('click', () => runAction(removeBtn, async () => { const ok = await window.jk.removeProfile(p.id); if (ok) { currentProfileId = ''; } return ok; }, 'Профиль убран из списка'));
    actions.append(selectBtn, folderBtn, removeBtn);
    row.append(icon, main, actions); root.appendChild(row);
  }
}
function renderAccount(account) {
  const loggedIn = !!account?.loggedIn && !!account?.profile;
  const profile = account?.profile;
  $('accountName').textContent = loggedIn ? profile.name : 'Не выполнен вход';
  $('accountState').textContent = loggedIn ? 'Minecraft Java Edition' : 'Microsoft account';
  $('accountAvatar').textContent = loggedIn ? (profile.name || '?').slice(0, 1).toUpperCase() : '?';
  $('loginButton').classList.toggle('hidden', loggedIn);
  $('logoutButton').classList.toggle('hidden', !loggedIn);
  renderSkin(account);
}
function renderSkin(account) {
  const profile = account?.profile;
  const loggedIn = !!account?.loggedIn && !!profile;
  $('skinAccountText').textContent = loggedIn ? 'Аккаунт подтверждён через Minecraft Services API.' : 'Войдите в Microsoft, чтобы просматривать и менять скин.';
  $('skinPlayerName').textContent = loggedIn ? profile.name : '—';
  $('skinPlayerUuid').textContent = loggedIn ? (profile.id || '—') : '—';
  const skin = loggedIn ? (profile.skins || []).find(s => s.state === 'ACTIVE') || (profile.skins || [])[0] : null;
  $('skinVariant').textContent = skin?.variant === 'SLIM' ? 'Slim / Alex' : skin ? 'Classic / Steve' : '—';
  $('skinPreviewLabel').textContent = loggedIn ? `Активный скин · ${profile.name}` : 'Нужен вход в Microsoft';
  if (skin?.url) {
    $('skinImage').src = skin.url;
    $('skinImage').classList.remove('hidden');
    $('skinPreviewFallback').classList.add('hidden');
  } else {
    $('skinImage').removeAttribute('src');
    $('skinImage').classList.add('hidden');
    $('skinPreviewFallback').classList.remove('hidden');
  }
  $('uploadSkinButton').disabled = !loggedIn;
}
function renderActiveModProfile() {
  const profile = currentProfile();
  const loaderName = profile ? ({ vanilla: 'Vanilla', fabric: 'Fabric', forge: 'Forge', neoforge: 'NeoForge' }[profile.loader] || profile.loader) : '';
  $('modsActiveProfile').textContent = profile ? `${profile.name} — Minecraft ${profile.mcVersion}, ${loaderName}` : 'Пока нет профилей. Создайте установку на главной.';
  $('importModsButton').disabled = !profile || profile.loader === 'vanilla';
}
function renderSettings() {
  if (!state) return;
  $('clientIdInput').value = state.settings.clientId || '';
  $('redirectInput').value = state.settings.redirect || 'http://localhost';
  $('memorySelect').value = state.settings.maxMemory || '4G';
  $('dataPath').textContent = state.dataPath || '—';
}
function applyTheme(theme) { document.documentElement.dataset.theme = theme === 'light' ? 'light' : 'dark'; try { localStorage.setItem('jk-theme', document.documentElement.dataset.theme); } catch {} }
const savedTheme = (() => { try { return localStorage.getItem('jk-theme') || 'dark'; } catch { return 'dark'; } })();
applyTheme(savedTheme);
const themeSelect = $('themeSelect'); if (themeSelect) { themeSelect.value = savedTheme; themeSelect.addEventListener('change', () => applyTheme(themeSelect.value)); }

async function refreshState(renderEverything = true) {
  state = await window.jk.getState();
  if (!currentProfileId || !state.profiles.some(p => p.id === currentProfileId)) currentProfileId = state.currentProfileId || state.profiles?.[0]?.id || '';
  if (renderEverything) renderVersions();
  else if (!$('mcVersionSelect').options.length || !$('mcVersionSelect').value) renderVersions();
  renderProfiles();
  renderAccount(state.account);
  renderSettings();
  renderInstances();
  $('systemText').textContent = `${state.platform} · v${state.appVersion}`;
}

for (const button of document.querySelectorAll('.nav-item')) button.addEventListener('click', () => switchView(button.dataset.view));
for (const button of document.querySelectorAll('[data-goto]')) button.addEventListener('click', () => switchView(button.dataset.goto));
$('selectedProfile').addEventListener('change', async event => {
  currentProfileId = event.target.value;
  if (currentProfileId) await window.jk.selectProfile(currentProfileId).catch(error => toast(friendlyError(error), 'error'));
  renderActiveProfile(); renderInstances();
});
$('mcVersionSelect').addEventListener('change', () => { $('visualVersion').textContent = `JAVA ${$('mcVersionSelect').value || 'EDITION'}`; });
$('createProfileOpen').addEventListener('click', () => { switchView('play'); $('profileNameInput').focus(); });
$('createProfileButton').addEventListener('click', async event => {
  const version = $('mcVersionSelect').value;
  if (!version) { toast('Список версий пока недоступен.', 'error'); return; }
  const profile = await runAction(event.currentTarget, () => window.jk.createProfile({ mcVersion: version, name: $('profileNameInput').value, loader: $('loaderSelect').value }), `Профиль Minecraft ${version} создан`);
  if (profile?.id) { currentProfileId = profile.id; $('profileNameInput').value = ''; await refreshState(); switchView('play'); }
});
$('playButton').addEventListener('click', event => {
  const profile = currentProfile();
  if (!profile) { switchView('play'); $('mcVersionSelect').focus(); return; }
  runAction(event.currentTarget, () => window.jk.launch(profile.id));
});
$('loginButton').addEventListener('click', event => runAction(event.currentTarget, () => window.jk.login(), 'Вход и проверка владения Minecraft выполнены'));
$('logoutButton').addEventListener('click', event => runAction(event.currentTarget, () => window.jk.logout(), 'Вы вышли из Microsoft'));
$('openDataFolder').addEventListener('click', () => window.jk.openFolder().catch(error => toast(friendlyError(error), 'error')));
$('openInstanceFolder').addEventListener('click', () => { const profile = currentProfile(); if (profile) window.jk.openGameFolder(profile.id).catch(error => toast(friendlyError(error), 'error')); });
$('settingsOpenFolder').addEventListener('click', () => window.jk.openFolder().catch(error => toast(friendlyError(error), 'error')));
$('refreshVersions').addEventListener('click', async event => {
  const list = await runAction(event.currentTarget, () => window.jk.refreshVersions(), 'Список релизов обновлён');
  if (Array.isArray(list)) { state.versions = list; renderVersions(); }
});
$('importMrpackButton').addEventListener('click', async event => {
  const profile = await runAction(event.currentTarget, () => window.jk.importMrpack());
  if (profile?.id) { currentProfileId = profile.id; await refreshState(); switchView('play'); toast('Модпак готов к запуску.', 'success'); }
});
$('quickImportButton').addEventListener('click', async event => {
  const profile = await runAction(event.currentTarget, () => window.jk.importMrpack());
  if (profile?.id) { currentProfileId = profile.id; await refreshState(); switchView('play'); toast('Модпак готов к запуску.', 'success'); }
});
$('importModsButton').addEventListener('click', event => {
  const profile = currentProfile();
  if (!profile) { toast('Сначала создайте или выберите Fabric-профиль.', 'error'); return; }
  runAction(event.currentTarget, () => window.jk.importMods(profile.id), 'ZIP модов добавлен в выбранную установку');
});
$('uploadSkinButton').addEventListener('click', async event => {
  const result = await runAction(event.currentTarget, () => window.jk.uploadSkin(), 'Скин обновлён в официальном профиле');
  if (result?.id) { state.account = { loggedIn: true, profile: result }; renderAccount(state.account); }
});
$('saveSettingsButton').addEventListener('click', async event => {
  const saved = await runAction(event.currentTarget, () => window.jk.saveSettings({ clientId: $('clientIdInput').value.trim(), redirect: $('redirectInput').value.trim(), maxMemory: $('memorySelect').value, minMemory: '2G' }), 'Настройки сохранены');
  if (saved) { state.settings = { ...state.settings, ...saved }; if (!saved.clientId) toast('Для Microsoft-входа нужен Client ID из Microsoft Entra.', 'error'); }
});
$('clearLog').addEventListener('click', () => { logBuffer.splice(0, logBuffer.length); $('logList').replaceChildren(); });
window.jk.onLog(appendLog);
window.jk.onStatus(setStatus);
window.jk.onProgress(setProgress);
window.jk.onAccount(account => { if (state) state.account = account; renderAccount(account); });

(async () => {
  try { await refreshState(); appendLog({ time: new Date().toLocaleTimeString('ru-RU'), message: 'JK Launcher GLOBAL 1.1.4 готов.', level: 'success' }); }
  catch (error) { appendLog({ time: new Date().toLocaleTimeString('ru-RU'), message: friendlyError(error), level: 'error' }); toast(friendlyError(error), 'error'); }
})();
