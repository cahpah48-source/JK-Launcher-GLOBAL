# JK Launcher GLOBAL 1.1.4

Исходный проект настольного лаунчера Minecraft Java Edition на Electron. Здесь нет имитации запуска: действия вызывают ядро загрузки Minecraft, скачивают совместимую Java Runtime, выполняют Microsoft OAuth, проверяют Minecraft entitlement, импортируют Fabric `.mrpack`, добавляют `.jar`-моды в Fabric-профиль и отправляют скин через Minecraft Services API.

## Возможности этой сборки

- Установки Minecraft хранятся в отдельных папках и не мешают друг другу.
- Список стабильных релизов берётся из официального Minecraft version manifest.
- Microsoft-вход через MSMC. Перед запуском проверяется владение Java Edition; офлайн-обход авторизации не реализован.
- Java Runtime скачивается автоматически с Adoptium: Java 25 для релизов 26.x, Java 21 для 1.20.5–1.21.x, Java 17 для 1.17–1.20.4, Java 8 для старых релизов.
- Импорт Modrinth `.mrpack` для Fabric: скачивание клиентских файлов с проверкой SHA-1/SHA-512, импорт `overrides`, установка Fabric Loader.
- Импорт ZIP с `.jar`-модами в уже созданный Fabric-профиль.
- Просмотр текущего скина и загрузка PNG 64×64 или 64×32 в официальный профиль; выбранная модель — Classic или Slim.
- Защищённое хранение refresh-сессии средствами `safeStorage` ОС, если оно доступно.
- Настройка RAM, игровой журнал, папки установок, интерфейс на русском языке.
- GitHub Actions собирает Windows installer `.exe` отдельно для x64 и ARM64.

## Честные ограничения

- `.mrpack` со сборщиком Forge отклоняется: в текущей версии установщик Forge не реализован. CurseForge archives и автоматическая загрузка модов из CurseForge API также не поддерживаются.
- Это первый рабочий исходный вариант, а не подписанный/сертифицированный релиз. На целевых Windows-машинах надо проверить OAuth с собственным Microsoft Application ID и запуск нескольких версий игры.
- Пиксельный редактор скинов не включён: доступно получение активного скина и его загрузка в официальный аккаунт.
- Автообновление самого лаунчера, Fabric/Forge switcher для уже установленных профилей, телеметрия/серверные профили и встроенный 3D-preview персонажа пока не входят в сборку.

## 1. Настроить Microsoft OAuth (обязательно)

1. Откройте [Microsoft Entra App registrations](https://entra.microsoft.com/).
2. Создайте приложение для личных Microsoft accounts (Accounts in any organizational directory and personal Microsoft accounts).
3. В **Authentication** добавьте платформу **Mobile and desktop applications** и URI `http://localhost/` (значение должно совпадать с полем в настройках лаунчера).
4. В **Advanced settings** включите **Allow public client flows**.
5. Скопируйте **Application (client) ID**.
6. Запустите лаунчер → **Настройки** → вставьте Client ID → **Сохранить настройки**.

Client ID является публичным идентификатором. Не вставляйте в лаунчер `client secret`, пароль Microsoft или токен. Окно Microsoft открывается библиотекой авторизации, пароль остаётся на стороне Microsoft.

Официальная инструкция: https://learn.microsoft.com/en-us/entra/identity-platform/scenario-desktop-app-configuration

## 2. Подготовить исходники из Termux

Termux на Android полезен для редактирования исходников и отправки проекта в GitHub, но он не является Windows-средой сборки Electron. Он не сможет надёжно собрать и запустить Windows `.exe` прямо на телефоне.

Понадобятся `git` и Node.js:

```bash
pkg update
pkg install git nodejs-lts
```

Распакуйте ZIP проекта, затем перейдите в его папку. Для локальной проверки синтаксиса:

```bash
npm install
npm run check
```

`npm start` рассчитан на настольную ОС с поддерживаемой Electron графической средой, а не на обычный Android/Termux.

## 3. Собрать EXE через GitHub Actions с телефона

1. Создайте новый пустой репозиторий на GitHub.
2. Распакуйте проект в Termux и загрузите папки/файлы в репозиторий. Можно использовать `git`:

```bash
git init
git add .
git commit -m "JK Launcher GLOBAL 1.1.4"
git branch -M main
git remote add origin https://github.com/ВАШ_АККАУНТ/ВАШ_РЕПОЗИТОРИЙ.git
git push -u origin main
```

3. Откройте репозиторий на GitHub → **Actions** → **Build JK Launcher GLOBAL for Windows** → **Run workflow**.
4. Дождитесь завершения двух заданий и скачайте артефакты `JK-Launcher-GLOBAL-Windows-x64` и `JK-Launcher-GLOBAL-Windows-arm64` внизу страницы выполнения workflow.
5. В каждом архиве будет Windows installer `.exe`.

Workflow использует Windows runner для сборки установщиков. Подписания сертификатом нет, поэтому Windows SmartScreen может показать предупреждение при первом запуске неподписанного приложения.

## Локальная сборка на Windows

Установите Node.js 22, распакуйте исходники и выполните:

```powershell
npm install
npm run check
npm run dist:win:x64
npm run dist:win:arm64
```

Результаты появляются в `dist/`.

## Каталоги данных

Папка настроек, игровых профилей, runtime и сохранённой зашифрованной сессии находится в `app.getPath('userData')/JKLauncher`. Точный путь отображается внутри раздела **Настройки**. У каждого игрового профиля есть собственная папка с мирами, конфигурациями, библиотеками и ресурсами.

## Зависимости

- Electron / electron-builder — интерфейс и сборка.
- `minecraft-launcher-core` — установка ресурсов и запуск Minecraft Java Edition.
- `msmc` — Microsoft/Xbox/Minecraft authentication flow.
- Adoptium API — дистрибутив Java Runtime.
- Fabric Meta / Fabric Installer — установка Fabric Loader.
- Minecraft Services API — профиль и загрузка скина.
