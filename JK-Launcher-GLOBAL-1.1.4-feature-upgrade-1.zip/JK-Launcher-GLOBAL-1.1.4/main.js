'use strict';

const { app, BrowserWindow, ipcMain, dialog, shell, safeStorage } = require('electron');
const path = require('node:path');
const fs = require('node:fs');
const fsp = require('node:fs/promises');
const os = require('node:os');
const crypto = require('node:crypto');
const { spawn } = require('node:child_process');
const { pipeline } = require('node:stream/promises');
const { Readable } = require('node:stream');
const extractZip = require('extract-zip');
const { PNG } = require('pngjs');
const { Client } = require('minecraft-launcher-core');
const { Auth } = require('msmc');

const APP_VERSION = '1.1.4';
let mainWindow;
let activeXbox = null;
let activeMinecraft = null;
let launcherClient = null;
let gameProcess = null;
let busy = false;
let latestVersions = [];

const dataRoot = () => path.join(app.getPath('userData'), 'JKLauncher');
const instancesRoot = () => path.join(dataRoot(), 'instances');
const runtimesRoot = () => path.join(dataRoot(), 'runtimes');
const settingsFile = () => path.join(dataRoot(), 'settings.json');
const profilesFile = () => path.join(dataRoot(), 'profiles.json');
const sessionFile = () => path.join(dataRoot(), 'session.enc');

function send(channel, payload) {
  if (mainWindow && !mainWindow.isDestroyed()) mainWindow.webContents.send(channel, payload);
}
function log(message, level = 'info') {
  send('jk:log', { message: String(message), level, time: new Date().toLocaleTimeString('ru-RU') });
}
function setStatus(message, state = 'idle') { send('jk:status', { message, state }); }
function setProgress(percent, message) {
  send('jk:progress', { percent: Math.max(0, Math.min(100, Number(percent) || 0)), message: String(message || '') });
}

function defaultSettings() {
  return { clientId: '', redirect: 'http://localhost/', maxMemory: '4G', minMemory: '2G' };
}
async function readJson(file, fallback) {
  try { return JSON.parse(await fsp.readFile(file, 'utf8')); } catch { return fallback; }
}
async function ensureDirectories() {
  await Promise.all([
    fsp.mkdir(dataRoot(), { recursive: true }),
    fsp.mkdir(instancesRoot(), { recursive: true }),
    fsp.mkdir(runtimesRoot(), { recursive: true })
  ]);
}
async function getSettings() {
  return { ...defaultSettings(), ...(await readJson(settingsFile(), {})) };
}
async function putSettings(input) {
  const current = await getSettings();
  const clientId = String(input.clientId ?? current.clientId).trim();
  const redirect = String(input.redirect ?? current.redirect).trim();
  const maxMemory = String(input.maxMemory ?? current.maxMemory);
  const minMemory = String(input.minMemory ?? current.minMemory);
  if (clientId && !/^[0-9a-fA-F-]{20,80}$/.test(clientId)) {
    throw new Error('Client ID должен быть GUID из Microsoft Entra App Registration.');
  }
  let redirectUrl;
  try { redirectUrl = new URL(redirect); } catch { throw new Error('Redirect URI должен быть корректным URL.'); }
  if (!['http:', 'https:'].includes(redirectUrl.protocol)) throw new Error('Разрешены только HTTP/HTTPS redirect URI.');
  if (!['localhost', '127.0.0.1'].includes(redirectUrl.hostname)) throw new Error('Для безопасности OAuth Redirect URI должен указывать на localhost или 127.0.0.1.');
  if (!['2G', '3G', '4G', '6G', '8G', '12G', '16G'].includes(maxMemory)) throw new Error('Недопустимое значение максимальной RAM.');
  if (!['1G', '2G', '3G', '4G'].includes(minMemory)) throw new Error('Недопустимое значение минимальной RAM.');
  const settings = { clientId, redirect, maxMemory, minMemory };
  await fsp.writeFile(settingsFile(), JSON.stringify(settings, null, 2), 'utf8');
  return settings;
}

async function getProfiles() {
  const entries = await readJson(profilesFile(), []);
  return Array.isArray(entries) ? entries : [];
}
async function saveProfiles(profiles) {
  await fsp.writeFile(profilesFile(), JSON.stringify(profiles, null, 2), 'utf8');
}
function slugify(value) {
  const slug = String(value || 'minecraft').toLowerCase()
    .normalize('NFKD').replace(/[^a-z0-9._-]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 50);
  return slug || 'minecraft';
}
function safePathWithin(base, relative) {
  const dest = path.resolve(base, relative);
  const rel = path.relative(path.resolve(base), dest);
  if (rel.startsWith('..') || path.isAbsolute(rel)) throw new Error(`Опасный путь в архиве: ${relative}`);
  return dest;
}

async function fetchJson(url, label = 'запрос') {
  const response = await fetch(url, { headers: { 'User-Agent': `JKLauncher/${APP_VERSION}` } });
  if (!response.ok) throw new Error(`${label}: HTTP ${response.status}`);
  return response.json();
}
async function getVersionList(force = false) {
  if (latestVersions.length && !force) return latestVersions;
  const manifest = await fetchJson('https://launchermeta.mojang.com/mc/game/version_manifest_v2.json', 'Манифест Minecraft');
  latestVersions = (manifest.versions || []).filter(v => v.type === 'release').slice(0, 120).map(v => ({ id: v.id, type: v.type, releaseTime: v.releaseTime }));
  return latestVersions;
}

function createAuth(settings) {
  if (!settings.clientId) throw new Error('Сначала откройте «Настройки» и укажите Microsoft OAuth Client ID.');
  return new Auth({ client_id: settings.clientId, redirect: settings.redirect || 'http://localhost/', prompt: 'select_account' });
}
async function ensureOwnsJava(minecraft) {
  const entitlements = await minecraft.entitlements();
  const strings = (Array.isArray(entitlements) ? entitlements : []).map(item => typeof item === 'string' ? item : JSON.stringify(item));
  if (!strings.some(item => /(?:^|[^a-z0-9_])(?:game_minecraft|product_minecraft)(?:$|[^a-z0-9_])/i.test(item)) || minecraft.isDemo?.()) {
    throw new Error('Эта учётная запись не подтвердила владение Minecraft Java Edition. Проверьте покупку/Game Pass и войдите снова.');
  }
}
async function writeEncryptedSession(xbox) {
  try {
    if (!safeStorage.isEncryptionAvailable()) {
      log('Защищённое хранилище ОС недоступно; вход сохранён только до закрытия лаунчера.', 'warn');
      await fsp.rm(sessionFile(), { force: true });
      return;
    }
    const encrypted = safeStorage.encryptString(xbox.save());
    await fsp.writeFile(sessionFile(), encrypted);
  } catch (error) {
    log(`Не удалось сохранить защищённую сессию: ${error.message}`, 'warn');
  }
}
async function signInWithXbox(xbox) {
  const minecraft = await xbox.getMinecraft();
  await ensureOwnsJava(minecraft);
  activeXbox = xbox;
  activeMinecraft = minecraft;
  await writeEncryptedSession(xbox);
  const profile = await refreshPlayerProfile();
  send('jk:account', { loggedIn: true, profile });
  setStatus(`Вход выполнен: ${profile.name}`, 'success');
  log(`Microsoft: вошли как ${profile.name} (${profile.id}).`);
  return profile;
}
async function tryRestoreSession() {
  const settings = await getSettings();
  if (!settings.clientId || !safeStorage.isEncryptionAvailable()) return;
  let token;
  try { token = safeStorage.decryptString(await fsp.readFile(sessionFile())); } catch { return; }
  if (!token) return;
  try {
    const xbox = await createAuth(settings).refresh(token);
    await signInWithXbox(xbox);
    log('Сохранённая сессия Microsoft восстановлена.');
  } catch (error) {
    await fsp.rm(sessionFile(), { force: true });
    log(`Сохранённая сессия истекла или недействительна: ${error.message}`, 'warn');
  }
}
async function refreshPlayerProfile() {
  if (!activeMinecraft) throw new Error('Сначала войдите в Microsoft.');
  const response = await fetch('https://api.minecraftservices.com/minecraft/profile', {
    headers: { Authorization: `Bearer ${activeMinecraft.mcToken}` }
  });
  if (!response.ok) throw new Error(`Не удалось получить профиль Minecraft: HTTP ${response.status}`);
  return response.json();
}

function platformTag() {
  if (process.platform === 'win32') return 'windows';
  if (process.platform === 'darwin') return 'mac';
  return 'linux';
}
function archTag() {
  if (process.arch === 'arm64') return 'aarch64';
  if (process.arch === 'ia32') return 'x86';
  return 'x64';
}
function requiredJavaMajor(version) {
  const m = String(version).match(/^(\d+)\.(\d+)(?:\.(\d+))?/);
  if (!m) return 21;
  const major = Number(m[1]);
  const minor = Number(m[2]);
  const patch = Number(m[3] || 0);
  if (major >= 26) return 25;
  if (major > 1 || (major === 1 && (minor > 20 || (minor === 20 && patch >= 5)))) return 21;
  if (major === 1 && minor >= 17) return 17;
  return 8;
}
async function findJavaExecutable(folder) {
  const expected = process.platform === 'win32' ? 'java.exe' : 'java';
  async function walk(dir, depth = 0) {
    if (depth > 5) return null;
    let items;
    try { items = await fsp.readdir(dir, { withFileTypes: true }); } catch { return null; }
    for (const item of items) {
      const full = path.join(dir, item.name);
      if (item.isFile() && item.name.toLowerCase() === expected.toLowerCase() && /[\\/]bin[\\/]/.test(full)) return full;
    }
    for (const item of items) {
      if (item.isDirectory()) {
        const found = await walk(path.join(dir, item.name), depth + 1);
        if (found) return found;
      }
    }
    return null;
  }
  return walk(folder);
}
async function downloadToFile(url, output, label = 'Загрузка') {
  await fsp.mkdir(path.dirname(output), { recursive: true });
  const response = await fetch(url, { headers: { 'User-Agent': `JKLauncher/${APP_VERSION}` } });
  if (!response.ok || !response.body) throw new Error(`${label}: HTTP ${response.status}`);
  await pipeline(Readable.fromWeb(response.body), fs.createWriteStream(output));
}
async function ensureJava(mcVersion, progressOffset = 0) {
  const major = requiredJavaMajor(mcVersion);
  const runtimeDir = path.join(runtimesRoot(), `java-${major}-${platformTag()}-${archTag()}`);
  const existing = await findJavaExecutable(runtimeDir);
  if (existing) return existing;
  if (process.platform === 'win32' || process.platform === 'linux' || process.platform === 'darwin') {
    const query = new URLSearchParams({ architecture: archTag(), heap_size: 'normal', image_type: 'jre', jvm_impl: 'hotspot', os: platformTag(), vendor: 'eclipse' });
    const assets = await fetchJson(`https://api.adoptium.net/v3/assets/latest/${major}/hotspot?${query}`, 'Adoptium Java');
    const packageUrl = assets?.[0]?.binary?.package?.link;
    if (!packageUrl) throw new Error(`Adoptium не вернул Java ${major} для ${platformTag()} ${archTag()}.`);
    const zipPath = path.join(dataRoot(), `java-${major}-${Date.now()}.zip`);
    log(`Скачиваем Java ${major} (${archTag()})…`);
    setProgress(progressOffset, `Загрузка Java ${major}…`);
    await downloadToFile(packageUrl, zipPath, `Java ${major}`);
    await fsp.mkdir(runtimeDir, { recursive: true });
    await extractZip(zipPath, { dir: runtimeDir });
    await fsp.rm(zipPath, { force: true });
    const java = await findJavaExecutable(runtimeDir);
    if (!java) throw new Error('Java скачана, но исполняемый файл не найден после распаковки.');
    if (process.platform !== 'win32') await fsp.chmod(java, 0o755).catch(() => {});
    log(`Java ${major} готова: ${java}`);
    return java;
  }
  throw new Error(`Автоматическая Java Runtime пока не настроена для ${process.platform}.`);
}

function runChild(command, args, cwd, label) {
  return new Promise((resolve, reject) => {
    log(`${label}: ${command} ${args.join(' ')}`);
    const child = spawn(command, args, { cwd, windowsHide: true, stdio: ['ignore', 'pipe', 'pipe'] });
    let output = '';
    child.stdout?.on('data', data => { const s = data.toString(); output += s; log(s.trim()); });
    child.stderr?.on('data', data => { const s = data.toString(); output += s; log(s.trim(), 'warn'); });
    child.once('error', reject);
    child.once('close', code => code === 0 ? resolve(output) : reject(new Error(`${label} завершился с кодом ${code}. ${output.slice(-1500)}`)));
  });
}
async function detectFabricVersion(gameDir, mcVersion) {
  const versionsDir = path.join(gameDir, 'versions');
  let names = [];
  try { names = await fsp.readdir(versionsDir, { withFileTypes: true }); } catch { return null; }
  for (const item of names) {
    if (!item.isDirectory() || !item.name.toLowerCase().includes('fabric')) continue;
    const jsonPath = path.join(versionsDir, item.name, `${item.name}.json`);
    try {
      const meta = JSON.parse(await fsp.readFile(jsonPath, 'utf8'));
      if (meta.inheritsFrom === mcVersion || item.name.includes(mcVersion)) return meta.id || item.name;
    } catch {}
  }
  return null;
}
async function installFabric(gameDir, mcVersion, loaderVersion, javaPath, reportProgress = true) {
  const existing = await detectFabricVersion(gameDir, mcVersion);
  if (existing) return existing;
  const versions = await fetchJson(`https://meta.fabricmc.net/v2/versions/loader/${encodeURIComponent(mcVersion)}`, 'Fabric metadata');
  const loader = loaderVersion || versions?.[0]?.loader?.version;
  if (!loader) throw new Error(`Для Minecraft ${mcVersion} не найден Fabric Loader.`);
  const installers = await fetchJson('https://meta.fabricmc.net/v2/versions/installer', 'Fabric installer metadata');
  const installer = (installers || []).find(x => x.stable) || installers?.[0];
  const installerUrl = installer?.url || (installer?.version ? `https://maven.fabricmc.net/net/fabricmc/fabric-installer/${installer.version}/fabric-installer-${installer.version}.jar` : null);
  if (!installerUrl) throw new Error('Не удалось определить ссылку Fabric Installer.');
  const installerPath = path.join(dataRoot(), `fabric-installer-${installer.version || 'latest'}.jar`);
  if (reportProgress) { setProgress(8, 'Подготовка Fabric Loader…'); log(`Устанавливаем Fabric Loader ${loader} для Minecraft ${mcVersion}.`); }
  await downloadToFile(installerUrl, installerPath, 'Fabric Installer');
  await fsp.mkdir(gameDir, { recursive: true });
  await runChild(javaPath, ['-jar', installerPath, 'client', '-dir', gameDir, '-mcversion', mcVersion, '-loader', loader, '-noprofile'], gameDir, 'Fabric Installer');
  const custom = await detectFabricVersion(gameDir, mcVersion);
  if (!custom) throw new Error('Fabric Installer отработал, но профиль Fabric не найден. Проверьте логи.');
  if (reportProgress) log(`Профиль Fabric создан: ${custom}`);
  return custom;
}

function attachLauncherEvents(client) {
  client.on('progress', p => {
    if (p && typeof p === 'object') {
      const progress = Number(p.task || p.progress || p.current || 0);
      const size = Number(p.total || p.size || 0);
      const percent = size > 0 ? Math.round((progress / size) * 100) : 0;
      setProgress(percent, 'Загрузка игровых файлов Minecraft…');
    } else log(`Загрузка: ${String(p)}`);
  });
  client.on('download-status', p => log(`Файлы: ${JSON.stringify(p)}`));
  client.on('debug', e => log(`[MC] ${typeof e === 'string' ? e : JSON.stringify(e)}`));
  client.on('data', e => log(`[ИГРА] ${String(e).trim()}`));
  client.on('close', code => {
    gameProcess = null;
    busy = false;
    setProgress(100, 'Minecraft закрыта');
    setStatus(`Minecraft завершила работу (код ${code}).`, code === 0 ? 'success' : 'warn');
    log(`Minecraft завершилась с кодом ${code}.`, code === 0 ? 'info' : 'warn');
  });
  client.on('error', e => log(`Ошибка Minecraft: ${e?.message || e}`, 'error'));
}

async function installForge(gameDir, mcVersion, javaPath) {
  const promotions = await fetchJson('https://files.minecraftforge.net/net/minecraftforge/forge/promotions_slim.json', 'Forge metadata');
  const promo = promotions?.promos || {};
  const forgeVersion = promo[`${mcVersion}-recommended`] || promo[`${mcVersion}-latest`];
  if (!forgeVersion) throw new Error(`Для Minecraft ${mcVersion} нет доступной рекомендуемой/последней версии Forge.`);
  const fullVersion = `${mcVersion}-${forgeVersion}`;
  const versionsDir = path.join(gameDir, 'versions');
  const already = (await fsp.readdir(versionsDir, { withFileTypes: true }).catch(() => [])).find(d => d.isDirectory() && /forge/i.test(d.name) && d.name.includes(mcVersion));
  if (already) return already.name;
  const installerUrl = `https://maven.minecraftforge.net/net/minecraftforge/forge/${fullVersion}/forge-${fullVersion}-installer.jar`;
  const installerPath = path.join(dataRoot(), `forge-${fullVersion}-installer.jar`);
  setProgress(8, `Загрузка установщика Forge ${forgeVersion}…`);
  await downloadToFile(installerUrl, installerPath, 'Forge Installer');
  await fsp.mkdir(gameDir, { recursive: true });
  await runChild(javaPath, ['-jar', installerPath, '--installClient', gameDir], gameDir, 'Forge Installer');
  const dirs = await fsp.readdir(versionsDir, { withFileTypes: true }).catch(() => []);
  const found = dirs.find(d => d.isDirectory() && /forge/i.test(d.name) && d.name.includes(mcVersion));
  if (!found) throw new Error('Forge installer завершился, но профиль Forge не найден. Проверьте журнал.');
  log(`Профиль Forge установлен: ${found.name}`);
  return found.name;
}
async function installNeoForge(gameDir, mcVersion, javaPath) {
  const match = /^1\.(\d+)\.(\d+)$/.exec(mcVersion);
  if (!match) throw new Error(`Не удалось определить совместимую версию NeoForge для Minecraft ${mcVersion}.`);
  const neoMajor = Number(match[1]);
  const neoMinor = Number(match[2]);
  const api = await fetchJson('https://maven.neoforged.net/api/maven/versions/releases/net/neoforged/neoforge', 'NeoForge metadata');
  const versions = Array.isArray(api?.versions) ? api.versions : Array.isArray(api) ? api : [];
  const compatible = versions.filter(v => new RegExp(`^${neoMajor}\\.${neoMinor}\\.\\d+$`).test(String(v))).sort((a,b) => String(b).localeCompare(String(a), undefined, {numeric:true}));
  const neoVersion = compatible[0];
  if (!neoVersion) throw new Error(`NeoForge не опубликовал совместимую версию для Minecraft ${mcVersion}.`);
  const profileName = `neoforge-${neoVersion}`;
  const versionsDir = path.join(gameDir, 'versions');
  const already = (await fsp.readdir(versionsDir, { withFileTypes: true }).catch(() => [])).find(d => d.isDirectory() && /neoforge/i.test(d.name) && d.name.includes(mcVersion));
  if (already) return already.name;
  const installerUrl = `https://maven.neoforged.net/releases/net/neoforged/neoforge/${neoVersion}/neoforge-${neoVersion}-installer.jar`;
  const installerPath = path.join(dataRoot(), `neoforge-${neoVersion}-installer.jar`);
  setProgress(8, `Загрузка установщика NeoForge ${neoVersion}…`);
  await downloadToFile(installerUrl, installerPath, 'NeoForge Installer');
  await fsp.mkdir(gameDir, { recursive: true });
  await runChild(javaPath, ['-jar', installerPath, '--installClient', gameDir], gameDir, 'NeoForge Installer');
  const installed = (await fsp.readdir(versionsDir, { withFileTypes: true }).catch(() => [])).find(d => d.isDirectory() && /neoforge/i.test(d.name) && d.name.includes(mcVersion));
  if (!installed) throw new Error('NeoForge installer завершился, но профиль NeoForge не найден. Проверьте журнал.');
  log(`Профиль NeoForge установлен: ${installed.name}`);
  return installed.name;
}

async function launchProfile(profileId) {
  if (busy) throw new Error('Лаунчер уже выполняет другую операцию.');
  if (!activeMinecraft) throw new Error('Перед запуском войдите в Microsoft и подтвердите владение Minecraft Java Edition.');
  const profiles = await getProfiles();
  const profile = profiles.find(p => p.id === profileId);
  if (!profile) throw new Error('Профиль не найден.');
  busy = true;
  try {
    setStatus('Подготовка Minecraft…', 'busy');
    setProgress(2, 'Подготовка окружения…');
    const javaPath = await ensureJava(profile.mcVersion, 4);
    let custom = profile.customVersion || undefined;
    if (profile.loader === 'fabric') {
      custom = await installFabric(profile.gameDir, profile.mcVersion, profile.loaderVersion, javaPath, false);
      profile.customVersion = custom;
      await saveProfiles(profiles);
    } else if (profile.loader === 'forge') {
      custom = await installForge(profile.gameDir, profile.mcVersion, javaPath);
      profile.customVersion = custom;
      await saveProfiles(profiles);
    } else if (profile.loader === 'neoforge') {
      custom = await installNeoForge(profile.gameDir, profile.mcVersion, javaPath);
      profile.customVersion = custom;
      await saveProfiles(profiles);
    }
    launcherClient = new Client();
    attachLauncherEvents(launcherClient);
    const settings = await getSettings();
    const options = {
      authorization: activeMinecraft.mclc(),
      root: profile.gameDir,
      version: { number: profile.mcVersion, type: 'release', ...(custom ? { custom } : {}) },
      memory: { max: settings.maxMemory, min: settings.minMemory },
      javaPath,
      timeout: 120000
    };
    log(`Запуск ${profile.name}: MC ${profile.mcVersion}${custom ? ` / ${custom}` : ''}.`);
    setStatus('Установка/запуск Minecraft…', 'busy');
    setProgress(3, 'Проверка игровых файлов…');
    gameProcess = await launcherClient.launch(options);
    if (!gameProcess) throw new Error('Ядро лаунчера не смогло создать процесс Minecraft.');
    gameProcess.once('close', code => {
      // MCLC may also emit close; its handler clears the state above.
      if (gameProcess) {
        gameProcess = null;
        busy = false;
        setStatus(`Minecraft завершила работу (код ${code}).`, code === 0 ? 'success' : 'warn');
      }
    });
    setStatus(`Minecraft запущена: ${profile.name}`, 'success');
    setProgress(100, 'Игра запущена');
    log('Процесс Minecraft запущен.');
    return { started: true, profile: profile.name };
  } catch (error) {
    busy = false;
    setStatus('Запуск не удался', 'error');
    setProgress(0, 'Ошибка');
    log(error.message, 'error');
    throw error;
  }
}

async function createVanillaProfile(mcVersion, displayName, loader = 'vanilla') {
  const versions = await getVersionList();
  if (!versions.some(v => v.id === mcVersion)) throw new Error('Выберите релиз Minecraft из официального списка.');
  const profiles = await getProfiles();
  if (!['vanilla', 'fabric', 'forge', 'neoforge'].includes(loader)) throw new Error('Неизвестный загрузчик.');
  const id = `${loader}-${slugify(mcVersion)}-${Date.now().toString(36)}`;
  const name = String(displayName || `Minecraft ${mcVersion}`).trim().slice(0, 70) || `Minecraft ${mcVersion}`;
  const gameDir = path.join(instancesRoot(), id);
  await fsp.mkdir(gameDir, { recursive: true });
  const profile = { id, name, mcVersion, loader, loaderVersion: '', customVersion: '', gameDir, createdAt: new Date().toISOString() };
  profiles.push(profile);
  await saveProfiles(profiles);
  await fsp.writeFile(path.join(dataRoot(), 'current-profile.txt'), id, 'utf8');
  log(`Создан профиль ${name}. Игровые файлы загрузятся при первом запуске.`);
  return profile;
}

async function shaFile(file, algorithm) {
  return new Promise((resolve, reject) => {
    const hash = crypto.createHash(algorithm);
    const stream = fs.createReadStream(file);
    stream.on('data', chunk => hash.update(chunk));
    stream.once('error', reject);
    stream.once('end', () => resolve(hash.digest('hex')));
  });
}
async function downloadVerified(url, destination, hashes = {}) {
  const parsed = new URL(url);
  if (parsed.protocol !== 'https:') throw new Error(`Отклонена небезопасная ссылка модпака: ${url}`);
  await fsp.mkdir(path.dirname(destination), { recursive: true });
  const tempPath = `${destination}.download-${Date.now()}`;
  await downloadToFile(url, tempPath, 'Файл модпака');
  for (const algorithm of ['sha512', 'sha1']) {
    if (hashes[algorithm]) {
      const actual = await shaFile(tempPath, algorithm);
      if (actual.toLowerCase() !== String(hashes[algorithm]).toLowerCase()) {
        await fsp.rm(tempPath, { force: true });
        throw new Error(`Не совпала контрольная сумма ${algorithm} у файла ${path.basename(destination)}.`);
      }
      break;
    }
  }
  await fsp.rename(tempPath, destination);
}
async function copyDirectoryContents(from, to) {
  await fsp.mkdir(to, { recursive: true });
  const names = await fsp.readdir(from);
  for (const name of names) {
    const src = path.join(from, name);
    const dest = path.join(to, name);
    await fsp.cp(src, dest, { recursive: true, force: true });
  }
}
async function importModrinthPack(archivePath) {
  if (busy) throw new Error('Дождитесь завершения текущей операции.');
  busy = true;
  const staging = await fsp.mkdtemp(path.join(os.tmpdir(), 'jk-mrpack-'));
  try {
    setStatus('Импорт Modrinth-модпака…', 'busy');
    setProgress(1, 'Проверяем архив…');
    await extractZip(archivePath, { dir: staging });
    const indexPath = path.join(staging, 'modrinth.index.json');
    let manifest;
    try { manifest = JSON.parse(await fsp.readFile(indexPath, 'utf8')); }
    catch { throw new Error('В архиве нет корректного modrinth.index.json. Для обычного ZIP используйте «Добавить ZIP модов».'); }
    const mcVersion = manifest?.dependencies?.minecraft;
    const deps = manifest?.dependencies || {};
    const loader = deps['fabric-loader'] ? 'fabric' : deps.forge ? 'forge' : deps.neoforge ? 'neoforge' : 'vanilla';
    const loaderVersion = deps['fabric-loader'] || deps.forge || deps.neoforge || '';
    if (!mcVersion) throw new Error('В manifest модпака не указана версия Minecraft.');
    const versions = await getVersionList();
    if (!versions.some(v => v.id === mcVersion)) throw new Error(`Релиз Minecraft ${mcVersion} не найден в официальном манифесте.`);
    const id = `modrinth-${slugify(manifest.name || 'pack')}-${Date.now().toString(36)}`;
    const gameDir = path.join(instancesRoot(), id);
    await fsp.mkdir(gameDir, { recursive: true });
    const overrides = path.join(staging, 'overrides');
    if (fs.existsSync(overrides)) await copyDirectoryContents(overrides, gameDir);
    const files = Array.isArray(manifest.files) ? manifest.files : [];
    let downloaded = 0;
    const filesToDownload = files.filter(file => file?.env?.client !== 'unsupported');
    for (let i = 0; i < filesToDownload.length; i += 5) {
      const batch = filesToDownload.slice(i, i + 5);
      await Promise.all(batch.map(async file => {
        if (!file.path || !Array.isArray(file.downloads) || !file.downloads.length) throw new Error('В manifest модпака обнаружен файл без пути или ссылки загрузки.');
        const dest = safePathWithin(gameDir, file.path.replace(/\\/g, '/'));
        const cachedHash = file.hashes?.sha1 || file.hashes?.sha512;
        if (cachedHash) {
          const algorithm = file.hashes.sha1 ? 'sha1' : 'sha512';
          try {
            if ((await shaFile(dest, algorithm)).toLowerCase() === String(cachedHash).toLowerCase()) { downloaded++; return; }
          } catch {}
        }
        const url = file.downloads.find(u => { try { return new URL(u).protocol === 'https:'; } catch { return false; } });
        if (!url) throw new Error(`У файла ${file.path} нет безопасной HTTPS-ссылки.`);
        await downloadVerified(url, dest, file.hashes || {});
        downloaded++;
        setProgress(5 + Math.round((downloaded / Math.max(1, filesToDownload.length)) * 55), `Файлы модпака: ${downloaded}/${filesToDownload.length}`);
      }));
    }
    const javaPath = await ensureJava(mcVersion, 65);
    let customVersion = '';
    if (loader === 'fabric') customVersion = await installFabric(gameDir, mcVersion, loaderVersion, javaPath, true);
    else if (loader === 'forge') customVersion = await installForge(gameDir, mcVersion, javaPath);
    else if (loader === 'neoforge') customVersion = await installNeoForge(gameDir, mcVersion, javaPath);
    const profile = {
      id,
      name: String(manifest.name || 'Modrinth Pack').trim().slice(0, 70),
      mcVersion,
      loader,
      loaderVersion,
      customVersion,
      gameDir,
      createdAt: new Date().toISOString(),
      source: 'Modrinth'
    };
    const profiles = await getProfiles();
    profiles.push(profile);
    await saveProfiles(profiles);
    await fsp.writeFile(path.join(dataRoot(), 'current-profile.txt'), id, 'utf8');
    setProgress(100, 'Модпак готов');
    setStatus(`Модпак импортирован: ${profile.name}`, 'success');
    log(`Импорт завершён: ${profile.name}; Minecraft ${mcVersion}; загрузчик ${loader}${loaderVersion ? ` ${loaderVersion}` : ''}; файлов ${downloaded}.`);
    return profile;
  } catch (error) {
    setStatus('Импорт модпака не удался', 'error');
    log(error.message, 'error');
    throw error;
  } finally {
    busy = false;
    await fsp.rm(staging, { recursive: true, force: true }).catch(() => {});
  }
}
async function importRawModsZip(archivePath, profileId) {
  if (busy) throw new Error('Дождитесь завершения текущей операции.');
  const profiles = await getProfiles();
  const profile = profiles.find(p => p.id === profileId);
  if (!profile) throw new Error('Сначала создайте или выберите профиль.');
  if (!['fabric', 'forge', 'neoforge'].includes(profile.loader)) throw new Error('Для установки модов нужен профиль Fabric, Forge или NeoForge.');
  busy = true;
  const staging = await fsp.mkdtemp(path.join(os.tmpdir(), 'jk-mods-'));
  try {
    setStatus('Импорт ZIP модов…', 'busy');
    await extractZip(archivePath, { dir: staging });
    let source = path.join(staging, 'mods');
    try { await fsp.access(source); } catch { source = staging; }
    const candidates = [];
    async function collect(dir) {
      for (const entry of await fsp.readdir(dir, { withFileTypes: true })) {
        const full = path.join(dir, entry.name);
        if (entry.isDirectory()) await collect(full);
        else if (entry.isFile() && entry.name.toLowerCase().endsWith('.jar')) candidates.push(full);
      }
    }
    await collect(source);
    if (!candidates.length) throw new Error('В ZIP не найдено ни одного .jar файла мода.');
    const modsDir = path.join(profile.gameDir, 'mods');
    await fsp.mkdir(modsDir, { recursive: true });
    for (const file of candidates) {
      const target = path.join(modsDir, path.basename(file));
      await fsp.copyFile(file, target);
    }
    setStatus(`Добавлено модов: ${candidates.length}`, 'success');
    log(`Импорт ZIP завершён: ${candidates.length} .jar → ${modsDir}`);
    return { count: candidates.length };
  } catch (error) {
    setStatus('Импорт ZIP не удался', 'error');
    log(error.message, 'error');
    throw error;
  } finally {
    busy = false;
    await fsp.rm(staging, { recursive: true, force: true }).catch(() => {});
  }
}

async function uploadSkin() {
  if (!activeMinecraft) throw new Error('Сначала войдите в Microsoft.');
  const choice = await dialog.showOpenDialog(mainWindow, {
    title: 'Выберите PNG-скин Minecraft',
    properties: ['openFile'],
    filters: [{ name: 'PNG skin', extensions: ['png'] }]
  });
  if (choice.canceled || !choice.filePaths?.[0]) return { canceled: true };
  const filePath = choice.filePaths[0];
  const bytes = await fsp.readFile(filePath);
  let png;
  try { png = PNG.sync.read(bytes); } catch { throw new Error('Файл не является корректным PNG.'); }
  if (!((png.width === 64 && png.height === 64) || (png.width === 64 && png.height === 32))) {
    throw new Error(`Размер скина ${png.width}×${png.height}. Нужен стандартный PNG 64×64 или 64×32.`);
  }
  const { response } = await dialog.showMessageBox(mainWindow, {
    type: 'question', buttons: ['Загрузить скин', 'Отмена'], defaultId: 0, cancelId: 1,
    title: 'Изменение скина Minecraft',
    message: `Загрузить этот скин в официальный профиль Minecraft?`,
    detail: `${path.basename(filePath)} (${png.width}×${png.height}). Скин изменится в вашей учётной записи.`
  }).then(r => ({ response: r.response }));
  if (response !== 0) return { canceled: true };
  const settings = await getSettings();
  const variantChoice = await dialog.showMessageBox(mainWindow, {
    type: 'question', buttons: ['Classic / Steve', 'Slim / Alex', 'Отмена'], defaultId: 0, cancelId: 2,
    title: 'Модель скина', message: 'Выберите модель персонажа.'
  });
  if (variantChoice.response === 2) return { canceled: true };
  const variant = variantChoice.response === 1 ? 'slim' : 'classic';
  const form = new FormData();
  form.append('variant', variant);
  form.append('file', new Blob([bytes], { type: 'image/png' }), path.basename(filePath));
  setStatus('Загрузка скина…', 'busy');
  const responseUpload = await fetch('https://api.minecraftservices.com/minecraft/profile/skins', {
    method: 'POST', headers: { Authorization: `Bearer ${activeMinecraft.mcToken}` }, body: form
  });
  if (!responseUpload.ok) {
    const text = await responseUpload.text().catch(() => '');
    throw new Error(`Minecraft API отклонил скин: HTTP ${responseUpload.status} ${text.slice(0, 400)}`);
  }
  const profile = await responseUpload.json();
  activeMinecraft.profile = profile;
  setStatus('Скин успешно изменён', 'success');
  log(`Официальный скин обновлён (${variant}).`);
  return profile;
}

async function buildState() {
  const settings = await getSettings();
  const profiles = await getProfiles();
  let currentProfileId = '';
  try { currentProfileId = (await fsp.readFile(path.join(dataRoot(), 'current-profile.txt'), 'utf8')).trim(); } catch {}
  if (!profiles.some(p => p.id === currentProfileId)) currentProfileId = profiles[0]?.id || '';
  let versions = [];
  let versionsError = null;
  try { versions = await getVersionList(); } catch (error) { versionsError = error.message; }
  let account = null;
  if (activeMinecraft) {
    try { account = await refreshPlayerProfile(); } catch { account = activeMinecraft.profile || null; }
  }
  return {
    appVersion: APP_VERSION,
    settings: { ...settings, clientId: settings.clientId },
    account: account ? { loggedIn: true, profile: account } : { loggedIn: false, profile: null },
    profiles,
    currentProfileId,
    versions,
    versionsError,
    dataPath: dataRoot(),
    platform: `${process.platform}/${process.arch}`,
    javaMajorHint: 'Java Runtime скачивается автоматически при первом запуске'
  };
}

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1360, height: 870, minWidth: 1050, minHeight: 700,
    backgroundColor: '#090b10', show: false,
    title: 'JK Launcher GLOBAL 1.1.4',
    webPreferences: { preload: path.join(__dirname, 'preload.js'), contextIsolation: true, nodeIntegration: false, sandbox: false }
  });
  mainWindow.loadFile(path.join(__dirname, 'renderer', 'index.html'));
  mainWindow.once('ready-to-show', () => mainWindow.show());
  mainWindow.webContents.setWindowOpenHandler(({ url }) => { shell.openExternal(url); return { action: 'deny' }; });
  mainWindow.on('closed', () => { mainWindow = null; });
}

app.whenReady().then(async () => {
  await ensureDirectories();
  createWindow();
  app.on('activate', () => { if (BrowserWindow.getAllWindows().length === 0) createWindow(); });
  await tryRestoreSession();
});
app.on('window-all-closed', () => { if (process.platform !== 'darwin') app.quit(); });

ipcMain.handle('jk:state', async () => buildState());
ipcMain.handle('jk:save-settings', async (_event, data) => {
  const settings = await putSettings(data || {});
  return { ...settings, clientId: settings.clientId };
});
ipcMain.handle('jk:login', async () => {
  if (busy) throw new Error('Дождитесь завершения текущей операции.');
  const settings = await getSettings();
  const auth = createAuth(settings);
  setStatus('Ожидаем вход Microsoft…', 'busy');
  log('Открываем окно официальной авторизации Microsoft…');
  try {
    const xbox = await auth.launch('electron', { width: 520, height: 720, resizable: true });
    return await signInWithXbox(xbox);
  } catch (error) {
    setStatus('Авторизация не завершена', 'error');
    log(`Microsoft OAuth: ${error.message || error}`, 'error');
    throw error;
  }
});
ipcMain.handle('jk:logout', async () => {
  activeXbox = null; activeMinecraft = null;
  await fsp.rm(sessionFile(), { force: true });
  send('jk:account', { loggedIn: false, profile: null });
  setStatus('Вы вышли из аккаунта', 'idle');
  log('Токены удалены из локального хранилища лаунчера.');
  return true;
});
ipcMain.handle('jk:create-profile', async (_event, data) => createVanillaProfile(String(data?.mcVersion || ''), String(data?.name || ''), String(data?.loader || 'vanilla')));
ipcMain.handle('jk:select-profile', async (_event, id) => {
  const profiles = await getProfiles();
  if (!profiles.some(p => p.id === id)) throw new Error('Профиль не найден.');
  await fsp.writeFile(path.join(dataRoot(), 'current-profile.txt'), id, 'utf8');
  return true;
});
ipcMain.handle('jk:remove-profile', async (_event, id) => {
  const profiles = await getProfiles();
  if (profiles.length <= 1) throw new Error('Нельзя удалить последний профиль.');
  const profile = profiles.find(p => p.id === id);
  if (!profile) throw new Error('Профиль не найден.');
  const answer = await dialog.showMessageBox(mainWindow, { type: 'warning', buttons: ['Убрать из списка', 'Отмена'], cancelId: 1, title: 'Удаление профиля', message: `Убрать «${profile.name}» из списка?`, detail: 'Файлы игры, моды и сохранения на диске останутся.' });
  if (answer.response !== 0) return false;
  await saveProfiles(profiles.filter(p => p.id !== id));
  const remaining = profiles.filter(p => p.id !== id);
  await fsp.writeFile(path.join(dataRoot(), 'current-profile.txt'), remaining[0].id, 'utf8');
  return true;
});
ipcMain.handle('jk:launch', async (_event, id) => launchProfile(String(id || '')));
ipcMain.handle('jk:import-mrpack', async () => {
  const result = await dialog.showOpenDialog(mainWindow, { title: 'Импорт Modrinth-модпака', properties: ['openFile'], filters: [{ name: 'Modrinth Modpack', extensions: ['mrpack'] }] });
  if (result.canceled || !result.filePaths?.[0]) return { canceled: true };
  return importModrinthPack(result.filePaths[0]);
});
ipcMain.handle('jk:import-mods', async (_event, profileId) => {
  const result = await dialog.showOpenDialog(mainWindow, { title: 'Выберите ZIP с модами .jar', properties: ['openFile'], filters: [{ name: 'ZIP archive', extensions: ['zip'] }] });
  if (result.canceled || !result.filePaths?.[0]) return { canceled: true };
  return importRawModsZip(result.filePaths[0], String(profileId || ''));
});
ipcMain.handle('jk:upload-skin', async () => {
  try { const profile = await uploadSkin(); if (profile?.id) send('jk:account', { loggedIn: true, profile }); return profile; }
  catch (error) { log(error.message, 'error'); setStatus('Не удалось изменить скин', 'error'); throw error; }
});
ipcMain.handle('jk:open-game-folder', async (_event, id) => {
  const profiles = await getProfiles();
  const profile = profiles.find(p => p.id === id);
  const target = profile?.gameDir || dataRoot();
  await fsp.mkdir(target, { recursive: true });
  await shell.openPath(target);
  return true;
});
ipcMain.handle('jk:open-folder', async () => { await shell.openPath(dataRoot()); return true; });
ipcMain.handle('jk:refresh-versions', async () => getVersionList(true));
